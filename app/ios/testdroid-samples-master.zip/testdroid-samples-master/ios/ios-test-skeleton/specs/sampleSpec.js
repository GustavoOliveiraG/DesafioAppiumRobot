describe("Sample test suite", function() {
    //get target
    var target = UIATarget.localTarget();

    it("Implement your test spec here", function(){
    });
});

