// UIAutomation does not define these functions.  Define them as no-ops here
// because Jasmine tries to manipulate them.
function setTimeout() {}
function clearTimeout() {}
function setInterval() {}
function clearInterval() {}

var exports = {}

