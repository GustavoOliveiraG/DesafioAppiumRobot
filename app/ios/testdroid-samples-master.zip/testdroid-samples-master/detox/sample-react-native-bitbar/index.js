import { AppRegistry } from 'react-native';
import sampleproject from './App';

AppRegistry.registerComponent('sampleproject', () => sampleproject);
