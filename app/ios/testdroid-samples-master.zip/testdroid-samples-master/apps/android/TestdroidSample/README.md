## Testdroid Sample
##### Testdroid sample Android App used as base to demo testing frameworks
**Note:**
Use Android Studio
