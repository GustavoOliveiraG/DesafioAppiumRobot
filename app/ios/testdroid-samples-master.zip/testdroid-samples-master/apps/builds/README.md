## Example Test Apps

These apps are meant to be used with Testdroid sample tests also located in this repository. The three available apps are:

* *BitbarIOSSAmple.ipa* - example native mobile app for testing with iOS devices

* *BitbarSampleApp.apk* - example native mobile app for testing with Android devices

* *Testdroid.apk* - example hybrid application to test hybrid testing on Android devices

