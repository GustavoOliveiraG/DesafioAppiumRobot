# Ruby Test Run Launcher

This is a sample Ruby test run launcher in Ruby. You can use this to launch
tests in Bitbar cloud or creating new projects.
