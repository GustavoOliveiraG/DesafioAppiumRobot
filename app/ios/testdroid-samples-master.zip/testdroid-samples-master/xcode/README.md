# XCTEST Example Project

Basic calculator app for iOS done with swift. Calculator can do addition and subtraction operations.

Project includes examples of unit tests written using XCTest framework.

## Building the IPA

Guide on how to build the IPA is available at Bitbar Testing [online documentation](http://docs.bitbar.com/testing/xcode/ipa/).

## Test Packaging

To run the XCTests in Bitbar Testing cloud, the tests need to be packaged into a zip-package.
The guide in how to do this is [available online](http://docs.bitbar.com/testing/xcode/xctest/).
