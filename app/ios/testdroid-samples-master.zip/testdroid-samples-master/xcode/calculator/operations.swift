//
//  operations.swift
//  calculator
//
//  Created by Petri Wunsch  on 12/12/2016.
//  Copyright © 2016 Petri W. All rights reserved.
//

import Foundation

class operations {
    
    func Addition(_ number1:Int, number2:Int)->Int {
        let Result = number1 + number2
        return Result
        
    }

    func Subtraction(_ number1:Int, number2:Int)->Int {
        let Result = number1 - number2
        return Result
        
    }


}

